# 1) OS / 아키텍처 확인 (noble + 64-bit)
lsb_release -sc                    # → noble
dpkg --print-architecture          # → amd64

# 2) repo 도구 + universe
sudo apt-get update
sudo apt-get install -y software-properties-common
sudo add-apt-repository -y universe
sudo apt-get install -y curl gnupg2 lsb-release build-essential

# 3) ROS2 apt key + 소스
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
  -o /etc/apt/keyrings/ros.gpg
sudo chmod a+r /etc/apt/keyrings/ros.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/ros.gpg] http://packages.ros.org/ros2/ubuntu noble main" \
  | sudo tee /etc/apt/sources.list.d/ros2.list
sudo apt-get update

# 4) ROS2 desktop + 개발 도구
sudo apt-get install -y \
  ros-jazzy-ament-package python3-pyqt5 ros-jazzy-ament-cmake libzmq3-dev
sudo apt-get install -y ros-jazzy-desktop
sudo apt-get install -y \
  python3-argcomplete python3-colcon-clean python3-colcon-common-extensions \
  python3-rosdep python3-vcstool

# 5) rosdep 초기화
sudo rosdep init
rosdep update

# 6) ~/.bashrc 자동 source 등록
echo "source /opt/ros/jazzy/setup.bash" >> ~/.bashrc
echo "source /usr/share/colcon_argcomplete/hook/colcon-argcomplete.bash" >> ~/.bashrc

# 검증
source /opt/ros/jazzy/setup.bash && ros2 pkg list >/dev/null && echo "ROS2 desktop OK"
