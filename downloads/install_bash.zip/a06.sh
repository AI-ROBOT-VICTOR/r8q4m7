sudo reboot

