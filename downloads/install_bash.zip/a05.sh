sudo apt-get update

# 1) 기반 라이브러리
sudo apt-get install -y git libpoco-dev libyaml-cpp-dev dbus-x11

# 2) robot / control 스택
sudo apt-get install -y \
  ros-jazzy-control-msgs ros-jazzy-realtime-tools ros-jazzy-xacro \
  ros-jazzy-joint-state-publisher-gui ros-jazzy-ros2-control \
  ros-jazzy-ros2-controllers ros-jazzy-moveit-msgs

# 3) lint / launch 유틸리티
sudo apt-get install -y \
  ros-jazzy-ament-lint-common ros-jazzy-yaml-cpp-vendor \
  ros-jazzy-ros2launch ros-jazzy-ament-pep257

# 4) Gazebo Harmonic
sudo apt-get install -y ros-jazzy-ros-gz

# 5) CycloneDDS RMW
sudo apt-get install -y ros-jazzy-rmw-cyclonedds-cpp
