# 0) git
sudo apt install git
sudo apt install gedit

# 1) HWE 커널 meta + headers 설치
sudo apt-get update
sudo apt-get install -y --install-recommends \
  linux-generic-hwe-24.04 linux-headers-generic-hwe-24.04

# 2) 부팅 커널 보강
sudo apt-get install -y "linux-modules-extra-$(uname -r)" "linux-headers-$(uname -r)"

