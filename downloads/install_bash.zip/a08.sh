# 1) 커널 소켓/fragment 버퍼 (재부팅해도 유지)
sudo tee /etc/sysctl.d/60-cyclonedds.conf >/dev/null <<'EOF'
# IP fragment 재조립
net.ipv4.ipfrag_time = 3
net.ipv4.ipfrag_high_thresh = 134217728
net.ipv4.ipfrag_low_thresh = 98304000
# UDP 수신 버퍼
net.core.rmem_max = 2147483647
net.core.rmem_default = 268435456
# UDP 송신 버퍼
net.core.wmem_max = 2147483647
net.core.wmem_default = 67108864
# NIC 수신 큐
net.core.netdev_max_backlog = 30000
EOF
sudo sysctl --system >/dev/null
echo "rmem_max=$(sysctl -n net.core.rmem_max) wmem_max=$(sysctl -n net.core.wmem_max)"

# 2) CycloneDDS XML 생성
mkdir -p ~/.config/cyclonedds
tee ~/.config/cyclonedds/cyclonedds.xml >/dev/null <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<CycloneDDS xmlns="https://cdds.io/config"
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xsi:schemaLocation="https://cdds.io/config https://raw.githubusercontent.com/eclipse-cyclonedds/cyclonedds/master/etc/cyclonedds.xsd">
  <Domain id="any">
    <General>
      <Interfaces>
        <NetworkInterface name="lo" priority="default" multicast="true"/>
      </Interfaces>
      <AllowMulticast>true</AllowMulticast>
    </General>
    <Internal>
      <SocketReceiveBufferSize min="64MB"/>
      <SocketSendBufferSize min="64MB"/>
    </Internal>
  </Domain>
</CycloneDDS>
EOF

# 3) ~/.bashrc 에 RMW / URI / DOMAIN_ID export
echo 'export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp' >> ~/.bashrc
echo 'export CYCLONEDDS_URI="file://$HOME/.config/cyclonedds/cyclonedds.xml"' >> ~/.bashrc
echo 'export ROS_DOMAIN_ID=<자기 번호>' >> ~/.bashrc

# 검증
cat ~/.config/cyclonedds/cyclonedds.xml
