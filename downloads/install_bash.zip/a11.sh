# 1) 시스템 오디오 라이브러리 (matplotlib 은 mic_test.py 파형 표시용)
sudo apt-get update
sudo apt-get install -y --no-install-recommends \
  python3-dev python3-pip python3-matplotlib \
  portaudio19-dev libportaudio2 libsndfile1 libasound2-dev ffmpeg

# PEP 668 우회
PIP='sudo python3 -m pip install --break-system-packages --no-cache-dir'

# 2) langchain / openai / 음성 스택
$PIP --ignore-installed --no-deps "typing-extensions>=4.14,<5"
$PIP "langchain<2" "langchain-openai<2" "openai<3" \
     pyaudio sounddevice "scipy<1.18" python-dotenv

# 3) openwakeword
$PIP --no-deps "openwakeword==0.6.0"

# 4) tflite-runtime
$PIP "onnxruntime<2,>=1.10.0" "tqdm<5,>=4.0" "scikit-learn<2,>=1" \
     "requests<3,>=2.0" "ai-edge-litert>=2.0.2,<3"
sudo python3 -c "import os,ai_edge_litert as a; d=os.path.join(os.path.dirname(os.path.dirname(a.__file__)),'tflite_runtime'); os.makedirs(d,exist_ok=True); open(os.path.join(d,'__init__.py'),'w').close(); open(os.path.join(d,'interpreter.py'),'w').write('from ai_edge_litert.interpreter import Interpreter\n')"

# 5) feature 모델 복사 + stock wakeword 다운로드
sudo env "OWW_SRC=$HOME/ros2_jazzy_test/resources/oww_models" python3 - <<'PY'
import os, shutil, openwakeword, openwakeword.utils
src = os.environ["OWW_SRC"]
dst = os.path.join(os.path.dirname(openwakeword.__file__), "resources", "models")
os.makedirs(dst, exist_ok=True)
for f in os.listdir(src):
    shutil.copy(os.path.join(src, f), dst)
openwakeword.utils.download_models()
bad = [f for f in sorted(os.listdir(dst))
       if f.endswith(".tflite") and open(os.path.join(dst, f), "rb").read(8)[4:8] != b"TFL3"]
for f in bad:
    os.remove(os.path.join(dst, f))
if bad:
    raise SystemExit("corrupt tflite (deleted, re-run to re-fetch): " + ", ".join(bad))
print("  models OK:", sorted(f for f in os.listdir(dst) if f.endswith(".tflite")))
PY

# 6) numpy<2 보장
$PIP "numpy<2"

# 검증
python3 - <<'PY'
import os, numpy as np
import langchain, langchain_openai, openai, openwakeword, tflite_runtime.interpreter, dotenv  # noqa: F401
from openwakeword.model import Model
d = os.path.join(os.path.dirname(openwakeword.__file__), "resources", "models")
m = Model(wakeword_models=[os.path.join(d, "alexa_v0.1.tflite")])  # stock 모델 — feature 모델 로드까지 함께 확인
m.predict(np.zeros(1280, dtype=np.int16))
assert np.__version__.startswith("1."), np.__version__
print("voice OK — numpy", np.__version__, "| Model(.tflite) load + predict OK")
PY
