# 1) 사전 도구
sudo apt-get update
sudo apt-get install -y ca-certificates curl

# 2) Docker keyring
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# 3) apt 소스 등록
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu noble stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list

# 4) 엔진 설치
sudo apt-get update
sudo apt-get install -y \
  docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 5) 엔진 패키지 버전 고정
sudo apt-mark hold docker-ce docker-ce-cli containerd.io

# 6) 현재 사용자를 docker 그룹에 추가
sudo usermod -aG docker "$USER"

# 검증
sudo docker run --rm hello-world
docker --version
docker compose version
